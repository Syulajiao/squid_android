package com.get.vpn.restful;

import android.os.Build;
import android.util.Log;

import com.alibaba.fastjson.JSONObject;
import com.google.android.gms.common.api.Api;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

/**
 * @author yu.jingye
 * @version created at 2016/10/2.
 */
public class VpnRestful {

    private static final String API_URL = "http://client.fastvd.com/";
    private static ApiEncrypt mEncrypt = new ApiEncrypt();

    public static Call login(String id, String password, String lastToken,Callback<ResponseBody> callback) {
        Retrofit retrofit = new Retrofit.Builder().baseUrl(API_URL).build();
        VpnApi vpnApi = retrofit.create(VpnApi.class);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", id);
        jsonObject.put("passwd", password);
        jsonObject.put("lasttoken", lastToken);
        jsonObject.put("os", "android_" + Build.VERSION.SDK_INT);
        jsonObject.put("time", System.currentTimeMillis() / 1000L);

        String strJsonBody = jsonObject.toString();
        byte[] srcJson = null;
        try {
            srcJson = strJsonBody.getBytes("UTF-8");
        }catch (UnsupportedEncodingException e){
            Log.e("VpnRestful", "getBytes('UTF-8') exception!" );
        };
        byte[] byteBody = mEncrypt.Encrypt(srcJson);

        RequestBody body = RequestBody.create(MediaType.parse("text/plain"), byteBody);

        Call<ResponseBody> call = vpnApi.login(body);
        call.enqueue(callback);
        return call;
    }

    public static Call logout(String id, String token, Callback<ResponseBody> callback) {
        Retrofit retrofit = new Retrofit.Builder().baseUrl(API_URL).build();
        VpnApi vpnApi = retrofit.create(VpnApi.class);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", id);
        jsonObject.put("token", token);
        jsonObject.put("time", System.currentTimeMillis() / 1000L);

        String strJsonBody = jsonObject.toString();
        byte[] srcJson = null;
        try {
            srcJson = strJsonBody.getBytes("UTF-8");
        }catch (UnsupportedEncodingException e){
            Log.e("VpnRestful", "getBytes('UTF-8') exception!" );
        };
        byte[] byteBody = mEncrypt.Encrypt(srcJson);

        RequestBody body = RequestBody.create(MediaType.parse("text/plain"), byteBody);

        Call<ResponseBody> call = vpnApi.logout(body);
        call.enqueue(callback);
        return call;
    }

    public static Call queryServers(String id, String token,Callback<ResponseBody> callback) {
        Retrofit retrofit = new Retrofit.Builder().baseUrl(API_URL).build();
        VpnApi vpnApi = retrofit.create(VpnApi.class);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", id);
        jsonObject.put("token", token);
        jsonObject.put("time", System.currentTimeMillis() / 1000L);

        String strJsonBody = jsonObject.toString();
        byte[] srcJson = null;
        try {
            srcJson = strJsonBody.getBytes("UTF-8");
        }catch (UnsupportedEncodingException e){
            Log.e("VpnRestful", "getBytes('UTF-8') exception!" );
        };
        byte[] byteBody = mEncrypt.Encrypt(srcJson);

        RequestBody body = RequestBody.create(MediaType.parse("text/plain"), byteBody);

        Call<ResponseBody> call = vpnApi.queryServers(body);
        call.enqueue(callback);
        return call;
    }

    public static Call heartBeatReport(String id, String token, String lineIp, Callback<ResponseBody> callback) {
        Retrofit retrofit = new Retrofit.Builder().baseUrl(API_URL).build();
        VpnApi vpnApi = retrofit.create(VpnApi.class);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", id);
        jsonObject.put("token", token);
        jsonObject.put("time", System.currentTimeMillis() / 1000L);
        jsonObject.put("lineip", lineIp);

        String strJsonBody = jsonObject.toString();
        byte[] srcJson = null;
        try {
            srcJson = strJsonBody.getBytes("UTF-8");
        }catch (UnsupportedEncodingException e){
            Log.e("VpnRestful", "getBytes('UTF-8') exception!" );
        };
        byte[] byteBody = mEncrypt.Encrypt(srcJson);

        RequestBody body = RequestBody.create(MediaType.parse("text/plain"), byteBody);

        Call<ResponseBody> call = vpnApi.heartBeatReport(body);
        call.enqueue(callback);
        return call;
    }

    public static String DecryptResponse(Response<ResponseBody> response){
        if (null == response || null == mEncrypt) {
            return null;
        }
        byte[] body = null;
        long length = 0;
        try {
            body = response.body().bytes();
        } catch (IOException e) {
            e.printStackTrace();
        }

        byte[] byteBody = mEncrypt.Decrypt(body);
        String retBody = null;
        try {
            retBody = new String(byteBody, "UTF-8");
        }catch (UnsupportedEncodingException e){
            retBody = null;
        }

        return retBody;
    }
}
